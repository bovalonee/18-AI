from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from config import bot_username
import csv

csv_file_path = 'plugins/channels.csv'
channels_submit_button = [[InlineKeyboardButton('✅', url=f'https://t.me/{bot_username}?start')]]
try:
    with open(csv_file_path, 'x'):
        pass
except FileExistsError:
    pass


def add_channel(name, username):
    with open(csv_file_path, 'a+') as file:
        writer = csv.writer(file)
        writer.writerow([name, username])


def remove_channel(username):
    with open(csv_file_path, 'r+') as file:
        reader = csv.reader(file)
        data = list(reader)
        for channel in data:
            if username in channel:
                data.remove(channel)
    with open(csv_file_path, 'w') as file:
        writer = csv.writer(file)
        writer.writerows(data)


def update_buttons():
    channels_buttons = []
    with open(csv_file_path, 'r+') as file:
        reader = csv.reader(file)
        for channel in reader:
            name, username = channel
            channels_buttons.append([InlineKeyboardButton(name, url=username)])
        else:
            markup_channels = InlineKeyboardMarkup(channels_buttons + channels_submit_button)
        return channels_buttons, markup_channels
