from apscheduler.schedulers.asyncio import AsyncIOScheduler
import aiosqlite
import datetime
import os


class Database:
    def __init__(self) -> None:
        filepath = os.path.dirname(os.path.realpath(__file__))
        # if system is windows
        if os.name == 'nt':
            path_sep = '\\'
        else:
            path_sep = '/'
        self.database = filepath + path_sep + 'database.db'
        self.conn = aiosqlite.connect(self.database)

    async def create_table_referral(self) -> None:
        async with aiosqlite.connect(self.database) as db:
            await db.execute("CREATE TABLE referrals (Inviter VARCHAR(15),Invited VARCHAR(15))")
            await db.commit()

    async def create_table_accounts(self) -> None:
        async with aiosqlite.connect(self.database) as db:
            await db.execute("CREATE TABLE accounts (Email VARCHAR(30) NOT NULL PRIMARY KEY,"
                             "Credit INTEGER DEFAULT 50,Is_Active BOOLEAN DEFAULT 0,Created DATETIME)")
            await db.commit()

    async def create_table_users(self) -> None:
        async with aiosqlite.connect(self.database) as db:
            await db.execute(
                'CREATE TABLE users (ChatId VARCHAR(15) PRIMARY KEY,Username VARCHAR(50) NULL,'
                'Fullname VARCHAR(70) NULL,Credit INTIGER DEFAULT 100,Blocked BOOLEAN DEFAULT 0 ,Created DATETIME)')
            await db.commit()

    async def create_table_steps(self):
        async with aiosqlite.connect(self.database) as db:
            await db.execute(
                'CREATE TABLE steps (ChatId VARCHAR(15) PRIMARY KEY,Step VARCHAR(50) DEFAULT "Registerd")')
            await db.commit()

    async def create_table_user_languages(self) -> None:
        async with aiosqlite.connect(self.database) as db:
            await db.execute(
                'CREATE TABLE languages (ChatId VARCHAR(15) PRIMARY KEY,Language VARCHAR(5) NULL)'
            )
            await db.commit()

    async def create_all_tables(self):
        await self.create_table_accounts()
        await self.create_table_steps()
        await self.create_table_users()
        await self.create_table_referral()
        await self.create_table_user_languages()

    async def read_count_all_referrals(self, inviter):
        async with aiosqlite.connect(self.database) as db:
            sql = 'SELECT Count(*) FROM referrals WHERE Inviter=?'
            val = (inviter,)
            cur = await db.execute(sql, val)
            result = await cur.fetchone()
            result = result[0]
            await cur.close()
            return result

    async def read_referrals(self, inviter):
        async with aiosqlite.connect(self.database) as db:
            sql = 'SELECT Invited FROM referrals WHERE Inviter=?'
            val = (inviter,)
            cur = await db.execute(sql, val)
            result = await cur.fetchone()
            await cur.close()
            return result

    async def add_referral_and_update_credit(self, inviter, invited):
        async with aiosqlite.connect(self.database) as db:
            sql = 'INSERT INTO referrals (Inviter,Invited) VALUES (?,?)'
            val = (inviter, invited)
            await db.execute(sql, val)
            sql = 'Update users SET Credit=Credit+100 WHERE ChatId=?'
            val = (inviter,)
            await db.execute(sql, val)
            await db.commit()

    async def add_account(self, email) -> None:
        async with aiosqlite.connect(self.database) as db:
            created = datetime.datetime.now()
            sql = 'INSERT INTO accounts (Email,Created) VALUES (?,?)'
            val = (email, created)
            await db.execute(sql, val)
            await db.commit()

    async def read_accounts(self, credit):
        async with aiosqlite.connect(self.database) as db:
            sql = f'SELECT Email FROM accounts WHERE Credit>={credit} AND Is_Active=0'
            cur = await db.execute(sql)
            result = await cur.fetchmany(10)
            await cur.close()
            return result

    async def update_account_is_active(self, is_active, email):
        async with aiosqlite.connect(self.database) as db:
            sql = 'UPDATE accounts SET Is_Active=? WHERE Email=?'
            val = (is_active, email)
            await db.execute(sql, val)
            await db.commit()

    async def update_account_credit(self, email, number):
        async with aiosqlite.connect(self.database) as db:
            sql = f'UPDATE accounts SET Credit=Credit-{number} WHERE Email=?'
            val = (email,)
            await db.execute(sql, val)
            await db.commit()

    async def update_daily_account_credit(self):
        async with aiosqlite.connect(self.database) as db:
            sql = 'UPDATE accounts SET Credit=50'
            await db.execute(sql)
            await db.commit()

    async def add_step(self, chat_id):
        async with aiosqlite.connect(self.database) as db:
            sql = 'INSERT OR REPLACE INTO steps (ChatId) VALUES (?)'
            val = (chat_id,)
            await db.execute(sql, val)
            await db.commit()

    async def update_step(self, chat_id, step):
        async with aiosqlite.connect(self.database) as db:
            sql = 'UPDATE steps SET Step=? WHERE ChatId=?'
            val = (step, chat_id)
            await db.execute(sql, val)
            await db.commit()

    async def read_step(self, chat_id) -> str:
        async with aiosqlite.connect(self.database) as db:
            sql = 'SELECT Step FROM steps WHERE ChatId=?'
            val = (chat_id,)
            cur = await db.execute(sql, val)
            result = await cur.fetchone()
            result = result[0]
            await cur.close()
            return result

    async def add_user(self, chat_id, username, firstname) -> None:
        async with aiosqlite.connect(self.database) as db:
            created = datetime.datetime.now()
            sql = 'INSERT OR IGNORE INTO users (ChatId,Username,Fullname,Created) VALUES (?,?,?,?)'
            val = (chat_id, username, firstname, created)
            await db.execute(sql, val)
            await db.commit()

    async def read_user_credit(self, chat_id):
        async with aiosqlite.connect(self.database) as db:
            sql = 'SELECT Credit FROM users WHERE ChatId=?'
            val = (chat_id,)
            cur = await db.execute(sql, val)
            result = await cur.fetchone()
            result = result[0]
            await cur.close()
            return result

    async def read_user_created(self, chat_id):
        async with aiosqlite.connect(self.database) as db:
            sql = 'SELECT Created FROM users WHERE ChatId=?'
            val = (chat_id,)
            cur = await db.execute(sql, val)
            result = await cur.fetchone()
            result = result[0]
            await cur.close()
            return result

    async def update_user_credit(self, chat_id, number):
        async with aiosqlite.connect(self.database) as db:
            sql = f'UPDATE users SET Credit=Credit-{number} WHERE ChatId=?'
            val = (chat_id,)
            await db.execute(sql, val)
            await db.commit()

    async def update_all_users_credit(self):
        async with aiosqlite.connect(self.database) as db:
            sql = 'UPDATE users SET Credit=100 WHERE Credit < 100'
            await db.execute(sql)
            await db.commit()

    async def full_access_user_credit(self, chat_id):
        async with aiosqlite.connect(self.database) as db:
            sql = 'UPDATE users SET Credit=Credit+99999 WHERE ChatId=?'
            val = (chat_id,)
            await db.execute(sql, val)
            await db.commit()

    async def update_user_blocked(self, chat_id, blocked):
        async with aiosqlite.connect(self.database) as db:
            sql = 'UPDATE users SET Blocked=? WHERE ChatId=?'
            val = (blocked, chat_id)
            await db.execute(sql, val)
            await db.commit()

    async def read_user_blocked(self, chat_id):
        async with aiosqlite.connect(self.database) as db:
            sql = 'SELECT Blocked FROM users WHERE ChatId=?'
            val = (chat_id,)
            cur = await db.execute(sql, val)
            result = await cur.fetchone()
            await cur.close()
            return result

    async def read_blocked_users(self):
        async with aiosqlite.connect(self.database) as db:
            sql = 'SELECT COUNT(ChatId) FROM users WHERE Blocked=1'
            cur = await db.execute(sql)
            result = await cur.fetchone()
            result = result[0]
            await cur.close()
            return result

    async def read_all_users_count(self):
        async with aiosqlite.connect(self.database) as db:
            sql = 'SELECT COUNT(ChatId) FROM users'
            cur = await db.execute(sql)
            result = await cur.fetchone()
            result = result[0]
            await cur.close()
            return result

    async def read_all_users(self):
        async with aiosqlite.connect(self.database) as db:
            sql = 'SELECT ChatId FROM users'
            cur = await db.execute(sql)
            result = await cur.fetchall()
            await cur.close()
            return result

    async def read_user_lang(self, chat_id):
        async with aiosqlite.connect(self.database) as db:
            sql = 'SELECT Language FROM Languages WHERE ChatId=?'
            val = (chat_id,)
            cur = await db.execute(sql, val)
            result = await cur.fetchone()
            await cur.close()
            return result

    async def add_user_lang(self, chat_id, lang):
        async with aiosqlite.connect(self.database) as db:
            sql = 'INSERT OR REPLACE INTO languages (ChatId,Language) VALUES (?,?)'
            val = (chat_id, lang)
            await db.execute(sql, val)
            await db.commit()


database = Database()

scheduler = AsyncIOScheduler(timezone='UTC')
scheduler.add_job(database.update_all_users_credit, 'cron', hour=0)
scheduler.add_job(database.update_daily_account_credit, 'cron', hour=0)
scheduler.start()

if not os.path.isfile(database.database):
    import asyncio

    loop = asyncio.get_event_loop()
    tsk = loop.create_task(database.create_all_tables())
    tsk.add_done_callback(lambda t: print('Database Created !'))
