from plugins.database import database as db
from pyrogram import filters
from pyrogram.types import Message
from pyrogram.errors import exceptions
from config import admin
from plugins.channels import update_buttons
from plugins import language


async def blocked(_, bot, query):
    chat_id = query.from_user.id
    result = await db.read_user_blocked(chat_id=chat_id)
    if result is None:
        await bot.send_message(chat_id, language.restart())
        return False
    elif result:
        if result[0] == 1:
            return False
        return True


is_blocked = filters.create(blocked)


async def join(_, bot, query: Message):
    user_id = query.from_user.id
    channels_buttons, markup_channels = update_buttons()
    if user_id == admin:
        return True
    try:
        for channel in channels_buttons:
            channel_url = '@' + channel[0].url.split('https://t.me/')[1]
            await bot.get_chat_member(
                chat_id=channel_url, user_id=user_id)
        return True

    # this except is for users that not joined the channels
    except exceptions.bad_request_400.UserNotParticipant:
        lang = await db.read_user_lang(chat_id=user_id)
        if lang is not None:
            lang = lang[0]
            text = language.join_channel_text(lang=lang)
            first_name = query.chat.first_name
            text = text % first_name
            await bot.send_message(
                chat_id=user_id,
                text=text,
                reply_markup=markup_channels)
            return False
        else:
            text = language.restart()
            await bot.send_message(
                chat_id=user_id,
                text=text)
            return False

    # this except is for admin that shows channels not found by bot
    except exceptions.BadRequest:
        await bot.send_message(
            chat_id=admin,
            text=f"ERROR: Channel not found",
            reply_markup=markup_channels)


# crating filter
is_join = filters.create(join)
