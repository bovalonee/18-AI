def dashboard_buttons_text(lang):
    languages = {
        'en': {'generate': '️❤️‍🔥 Generate', 'my-account': '👤 My account', 'back': '️🔙 Back', 'admin': '🔑 Admin'},
        'fa': {'generate': 'ساخت عکس ️❤️‍🔥', 'my-account': 'اکانت من 👤', 'back': 'بازگشت ️🔙', 'admin': 'ادمین 🔑'}}
    return languages[lang]


def welcome_text(lang) -> str:
    languages = {
        'en': '''
Hello %s 👋
I'm an Image generator bot!
I can create Anime or Realistic Images, fast and simple.
🔖 Select the section you need from the menu and then select your image size and send me your prompt to generate image.
''',
        'fa': '''
سلام %s خوش اومدی 🌹

➕ با من به راحتی با متن،عکس درست کن

🔸 برای شروع با کمک گرفتن از دکمه های پایینی عکس مورد نظر خودت رو بساز :
    '''}
    return languages[lang]


def error_404_text(lang):
    languages = {'en': 'What??\nI didn\'t understand ', 'fa': 'متوجه نشدم !؟'}
    return languages[lang]


def send_prompt_text(lang):
    languages = {'en': '''
Now Send your prompt
⚠️ Your prompt must be comma separated.
For example : 👇
A bear riding motorcycle,(masterpiece),best quality,prefect face,expressive eyes''',
                 'fa': '''
حال متن خود را ارسال کنید
متن شما باید انگلیسی با کاما(،) جدا شده باشد ⚠️
برای مثال : 👇
A bear riding motorcycle,(masterpiece),best quality,prefect face,expressive eyes
'''}
    return languages[lang]


def user_account(lang):
    languages = {'en': {'buy-credit': '💲 Buy credit', 'invite-link': '📬 Invite link',
                        'not-enough-credit': '❌ You don\'t have enough credit, please try again the next day ❌',
                        'detail': '''
👤 ID: %s
💰 Credit: %s
🕐 Date: %s
📥 Invited: %s'''},
                 'fa': {'buy-credit': 'خرید اعتبار 💲', 'invite-link': 'لینک دعوت 📬',
                        'not-enough-credit': '❌ شما اعتبار کافی ندارید لطفا فردا مجددا تلاش کنید ❌',
                        'detail': '''
👤 ایدی : %s
💰 اعتبار : %s
🕐 تاریخ : %s
📥 دعوت شده ها: %s'''}}
    return languages[lang]


def admin_panel_texts(lang):
    languages = {'en': {'welcome': 'Welcome my lord', 'permission': 'You don\'t have permission to this section ❗️'},
                 'fa': {'welcome': 'خوش آمدید سرورم', 'permission': 'شما اجازه دسترسی به این بخش را ندارید ❗️'}}
    return languages[lang]


def user_wallet(lang):
    languages = {'en': {'request': '✅ Your request has been sent to the admin for review\nPlease be patient ❕',
                        'accept': '✅ Accept',
                        'reject': '❌ Reject',
                        'admin-info-text': '''
💳 Transaction review request 💳
ID: %s
First name: %s
Username: @%s
Wallet: %s'''},
                 'fa': {'request': '✅ درخواست شما برای بررسی به ادمین ارسال شد\nلطفا صبور باشید ❕',
                        'accept': 'تایید ✅',
                        'reject': 'تکذیب ❌',
                        'admin-info-text': '''
💳 درخواست بررسی تراکنش 💳
ایدی عددی: %s
نام: %s
ایدی: @%s
ولت: %s'''}}
    return languages[lang]


def seed_text(lang):
    languages = {
        'en': {'success': 'Your seed has been successfully modified', 'error': '❌ Error: Your seed must be a number'},
        'fa': {'success': 'با موفقیت ویرایش شد', 'error': '❌ ارور: seed شما باید عدد باشد'}}
    return languages[lang]


def admin_block_text(lang):
    languages = {'en': 'Successfully blocked.', 'fa': 'با موفقیت بلاک شد'}
    return languages[lang]


def admin_unblock_text(lang):
    languages = {'en': 'Successfully unblocked.', 'fa': 'با موفقیت انبلاک شد'}
    return languages[lang]


def admin_add_channel_texts(lang):
    languages = {'en': {'success': 'Successfully added.', 'fail': 'Error ,You must send channel link'},
                 'fa': {'success': 'با موفقیت اضافه شد', 'fail': 'ارور، شما باید لینک کانال را ارسال کنید'}}
    return languages[lang]


def admin_remove_channel_text(lang):
    languages = {'en': 'Successfully removed.', 'fa': 'با موفقیت حذف شد'}
    return languages[lang]


def task_settings_texts(lang):
    languages = {'en': {'main-text': 'You can change your size and model by going to the desired section',
                        'size': '🖼 Size',
                        'model': '👥 Model',
                        'extra-settings': '⚙️ Extra settings',
                        'generate': '✅ Generate',
                        },
                 'fa': {'main-text': 'شما میتوانید اندازه و مدل مورد نظر خود را با رفتن به بخش مربوطه تغییر دهید',
                        'size': '🖼 اندازه',
                        'model': '👥 مدل',
                        'extra-settings': '⚙️ تنظیمات بیشتر',
                        'generate': '✅ ساخت تصویر'}}
    return languages[lang]


# -------------------
def invite_link(lang):
    languages = {'en': '''
✅ You can invite your friends and get 100 points easily
    
Your invite link ⬇️
%s''',
                 'fa': '''
✅ شما میتوانید دوستان خود را دعوت کنید و به راحتی ۱۰۰ اعتبار دریافت کنید.
    
لینک دعوت شما ⬇️
%s'''}
    return languages[lang]


def buy_credit(lang):
    languages = {'en': {'text': '''
✅ You can buy unlimited access to this robot for only 20 Trons

⚠️ To buy, send 20 trons to the wallet below and press the next button and then send your wallet address and wait for it to be checked by the admin.

Tron: `%s`''', 'next': '⏭ Next'},
                 'fa': {'text': '''
✅ شما میتوانید دسترسی نامحدود این ربات را فقط با ۲۰ ترون خریداری کنید
⚠️ برای خرید، ۲۰ ترون را به کیف پول زیر واریز کنید و سپس گزینه ادامه را بزنید و بعد آدرس کیف پول خود را وارد کنید و منتظر بمانید تا توسط ادمین تایید شود.
آدرس کیف پول: `%s`
''', 'next': '⏭ ادامه'}}
    return languages[lang]


def submit_credit(lang):
    languages = {'en': 'Now send your wallet address.',
                 'fa': 'حال آدرس کیف پول خود را ارسال کنید'}
    return languages[lang]


def full_access_credit(lang):
    languages = {
        'en': {'congratulation': '🎉 Congratulations, you now have unlimited credit 🥳', 'accept': '✅✅✅✅ Accepted ✅✅✅✅'},
        'fa': {'congratulation': '🎉 تبریک میگویم،حال شما دسترسی نامحدود دارید 🥳', 'accept': '✅✅✅✅ تایید شد ✅✅✅✅'}}
    return languages[lang]


def fake_credit_request(lang):
    languages = {
        'en': {'text': 'Admin:\n❌ You sent a fake request and you\'ll be blocked if you repeat it again ❌',
               'reject': '❌❌❌❌ Rejected ❌❌❌❌',
               'block': '💀 Block 💀'},
        'fa': {'text': 'ادمین:\n❌ شما یک درخواست جعلی ارسال کردید و در صورت تکرار بلاک خواهید شد ❌',
               'reject': '❌❌❌❌ تکذیب شد ❌❌❌❌',
               'block': '💀 بلاک 💀'}}
    return languages[lang]


def admin_panel_callback_query_texts(lang):
    languages = {
        'en': {'admin-home': 'Welcome my lord',
               'admin-block': 'Send the user ID to block.',
               'admin-unblock': 'Send the user ID to unblock.',
               'admin-status': '''
📈 Users: %s
📉 Blocks: %s              
''',
               'admin-add-channel': 'Send your channel name,link\nLike this:\nTelegram,https://t.me/telegram',
               'admin-remove-channel': 'Send your channel link\nLike this:\nhttps://t.me/telegram',
               'admin-send-message': 'Please send your message',
               'back': '️🔙 Back'},
        'fa': {'admin-home': 'خوش آمدید سرورم',
               'admin-block': 'ایدی عددی کاربر را برای بلاک کردن ارسال کنید',
               'admin-unblock': 'ایدی عددی کاربر را برای آنبلاک کردن ارسال کنید',
               'admin-status': '''
📈 کاربران: %s
📉 کاربران بلاک شده: %s
''',
               'admin-add-channel': 'اسم چنل،لینک چنل را ارسال کنید مانند زیر\nTelegram,https://t.me/telegram',
               'admin-remove-channel': 'لینک کانال مورد نظر خود را مانند زیر ارسال کنید\nhttps://t.me/telegram',
               'admin-send-message': 'لطفا پیغام خود را ارسال کنید',
               'back': 'بازگشت ️🔙'}}
    return languages[lang]


def block_credit_request(lang):
    languages = {
        'en': {'text': 'Admin:\n💀 You\'ve been blocked due to fake requests 💀\nByE bYe',
               'block': '💀💀💀💀 BLOCKED 💀💀💀💀'},
        'fa': {'text': 'ادمین:\n💀 شما به دلیل ارسال درخواست تراکنش جعلی بلاک شدید 💀\nبای بای',
               'block': '💀💀💀💀 بلاک شد 💀💀💀💀'}}
    return languages[lang]


def change_size(lang):
    languages = {
        'en': {'size': '🖼 Size',
               'text': '''
🖼 Choose your image size
Landscape | 3:2 | 10 Credit
Portrait       | 2:3 | 10 Credit
Normal       | 1:1 | 5  Credit'''},
        'fa': {'size': '🖼 اندازه',
               'text': '''
🖼 اندازه تصویر خود را انتخاب کنید
افقی | ۳:۲ | ۱۰ اعتبار
عمودی | ۲:۳ | ۱۰ اعتبار
عادی | ۱:۱ | ۵ اعتبار
'''}}
    return languages[lang]


def change_size_done(lang):
    languages = {
        'en': {'landscape': 'Landscape', 'portrait': 'Portrait', 'normal': 'Normal'},
        'fa': {'landscape': 'افقی', 'portrait': 'عمودی', 'normal': 'عادی'}}
    return languages[lang]


def change_model(lang):
    languages = {
        'en': {'model': '👥 Model', 'text': '👥 Choose the model you want'},
        'fa': {'model': '👥 مدل', 'text': '👥 مدل مورد نظر خود را انتخاب کنید'}}
    return languages[lang]


def extra_settings(lang):
    languages = {
        'en': {'extra-settings': '⚙️ Extra settings', 'back': '️🔙 Back', 'text': '⚙️ Now you can apply more settings'},
        'fa': {'extra-settings': '⚙️ تنظیمات بیشتر', 'back': '️🔙 بازگشت',
               'text': '⚙️ حال میتوانید تنظیمات بیشتری را اعمال کنید'}}
    return languages[lang]


def generate(lang):
    languages = {
        'en': {'not-enough-credit': 'You don\'t have credit ❌',
               'active-task': 'You have an active task ❌',
               'wait': 'Please Wait ❕',
               'generate': '🔄 Generating...\n\n**⚠️ In order to deal with Telegram\'s extensive filtering, the photos will be deleted after 60 seconds. To view them, send them to your saved messages and view them there.**',
               'failed': '❌ Task failed due to taking too long to generate, please try again ❌',
               'accept': '✅',
               'reject': '❌'},
        'fa': {'not-enough-credit': 'شما اعتبار کافی ندارید ❌',
               'active-task': 'شما یک پردازش نااتمام دارید ❌',
               'wait': 'لطفا صبر کنید ❕',
               'generate': '🔄 درحال پردازش...\n\n**⚠️ به دلیل فیلترینگ گسترده تلگرام عکسا پس از ۶۰ ثانیه حذف خواهند شد،جهت مشاهده آنها را به پیوی خود (Saved messages) بفرستید و آنجا مشاهده کنید.**',
               'failed': '❌ به دلیل طولانی شدن پردازش،پردازش ناموفق بود ❌',
               'accept': '✅',
               'reject': '❌'
               }}
    return languages[lang]


def generate_admin_buttons(lang):
    languages = {
        'en': {'accept': '✅ Accept ',
               'reject': '❌ Reject '},
        'fa': {
            'accept': '✅ تایید',
            'reject': '❌ عدم تایید'
        }}
    return languages[lang]


def admin_panel_create_buttons(lang):
    languages = {
        'en': {'status': '📊 Status', 'block': '❌ Block', 'unblock': '✅ Unblock', 'add-channel': '➕ Add channel',
               'remove-channel': '➖ Remove channel', 'send-message': '✉️ Send message'},
        'fa': {'status': '📊 آمار', 'block': '❌ بلاک', 'unblock': '✅ آنبلاک', 'add-channel': '➕ اضافه کردن کانال',
               'remove-channel': '➖ حذف کردن کانال', 'send-message': '✉️ ارسال پیام'}}
    return languages[lang]


def restart():
    text = '''
Please restart the bot /start

لطفا ربات را مجددا استارت کنید /start
'''
    return text


def join_channel_text(lang):
    languages = {
        'en': '''
Hello %s 👋
To use the robot, you must first join to the following channels and then click on submit.''',
        'fa': '''
سلام %s 👋
برای استفاده از ربات ابتدا وارد کانال های زیر شوید و سپس گزینه تایید را بزنید
        '''}
    return languages[lang]


def select_language(lang):
    languages = {
        'en': 'Your language has been successfully changed to English 🇺🇸\nPlease restart the bot /start',
        'fa': 'زبان شما با موفقیت به فارسی تغییر پیدا کرد 🇮🇷\nلطفا ربات را مجددا استارت کنید /start'}
    return languages[lang]


def admin_send_message(lang):
    languages = {
        'en': {'wait': 'Please Wait ❕',
               'success': '''
Your message has been sent successfully

📊 Total users: %s
✅ Sent messages: %s
🚫 Blocked messages: %s
'''},
        'fa': {'wait': 'لطفا صبر کنید ❕',
               'success': '''
پیغام شما با موفقیت ارسال شد

📊 کل کاربران: %s
✅ پیغام های ارسال شده: %s
🚫 پیغام های بلاک شده: %s
'''
               }}
    return languages[lang]

def try_again(lang):
    languages = {
        'en': 'Please try again',
        'fa': 'لطفا مجددا تلاش کنید'}
    return languages[lang]

