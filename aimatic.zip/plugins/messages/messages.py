from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
import logging
from pyrogram.errors import exceptions
from plugins.database import database as db
from plugins.commands.start import start
from plugins.filters import is_blocked, is_join
import re
from config import admin
from plugins import channels, language
from plugins.messages import callbackquery as cbq


@Client.on_message(filters.text & filters.private & is_join & is_blocked)
async def messages(bot: Client, message: Message):
    chat_id, text = message.chat.id, message.text
    lang = await db.read_user_lang(chat_id=chat_id)
    try:
        lang = lang[0]
        dashboard_buttons = language.dashboard_buttons_text(lang=lang)
        error_404_text = language.error_404_text(lang=lang)
        cases = [
            (fr'{dashboard_buttons["back"]}', r'.*', start),
            (fr'{dashboard_buttons["my-account"]}', r'.*', user_account),
            (fr'{dashboard_buttons["generate"]}', r'.*', get_prompt),

            (fr'{dashboard_buttons["admin"]}', r'.*', admin_panel),
            (r'.*', r'^get-prompt$', get_prompt_done),
            (r'.*', r'extra-settings-seed', extra_get_seed),
            (r'.*', r'Submit-Credit', get_user_wallet),
            (r'.*', r'Admin-Block', admin_block),
            (r'.*', r'Admin-Unblock', admin_unblock),
            (r'.*', r'Add-Channel', admin_add_channel),
            (r'.*', r'Remove-Channel', admin_remove_channel),
            ('.*', r'Send-Message-To-Users', admin_send_message)

        ]

        user_step = await db.read_step(chat_id)
        for pattern, step, callback in cases:
            if re.match(pattern, text) and re.match(step, user_step):
                await callback(bot, message, lang)
                break
        else:
            await message.reply_text(error_404_text)
    except (ValueError, KeyError, TypeError):
        logging.warning('Exception occurred', exc_info=True)
        logging.info('PASSED')
        await bot.send_message(chat_id, language.restart())


async def get_prompt(_: Client, message: Message, lang):
    chat_id = message.chat.id
    await db.update_step(chat_id=chat_id, step='get-prompt')
    text = language.send_prompt_text(lang=lang)
    await message.reply_text(text=text, reply_to_message_id=message.id)


async def get_prompt_done(_: Client, message: Message, lang):
    chat_id = message.chat.id
    prompt = message.text
    await db.update_step(chat_id=chat_id, step='get-prompt-done')
    reply_markup, text = cbq.update_task_setting(chat_id, prompt=prompt, lang=lang)
    await message.reply_text(text, reply_markup=reply_markup, reply_to_message_id=message.id)


async def user_account(_: Client, message: Message, lang):
    chat_id = message.chat.id
    user_credit = await db.read_user_credit(chat_id=chat_id)
    user_created = await db.read_user_created(chat_id=chat_id)
    user_invited = await db.read_count_all_referrals(inviter=chat_id)
    user_account_texts = language.user_account(lang=lang)

    reply_markup = InlineKeyboardMarkup(
        [[InlineKeyboardButton(text=user_account_texts['buy-credit'], callback_data='buy-credit')],
         [InlineKeyboardButton(text=user_account_texts['invite-link'], callback_data='invite-link')]])
    if not user_credit:
        user_credit = user_account_texts['not-enough-credit']
    text = user_account_texts['detail'] % (chat_id, user_credit, user_created, user_invited)
    await message.reply_text(text, reply_markup=reply_markup, reply_to_message_id=message.id)


async def admin_panel(_: Client, message: Message, lang):
    chat_id = message.chat.id
    texts = language.admin_panel_texts(lang=lang)
    if chat_id == admin:
        reply_markup = cbq.admin_panel_create_buttons(lang)
        await message.reply_text(text=texts['welcome'], reply_markup=reply_markup)
    else:
        await message.reply_text(texts['permission'], reply_to_message_id=message.id)


async def get_user_wallet(bot: Client, message: Message, lang):
    wallet = message.text
    chat_id = message.chat.id
    texts = language.user_wallet(lang=lang)
    await message.reply_text(text=texts['request'], reply_to_message_id=message.id)
    username, firstname = message.chat.username, message.chat.first_name
    reply_markup = InlineKeyboardMarkup([[InlineKeyboardButton(texts['accept'], f'full-{chat_id}')],
                                         [InlineKeyboardButton(texts['reject'], callback_data=f'fake-{chat_id}')]])
    text = texts['admin-info-text'] % (chat_id, firstname, username, wallet)
    await bot.send_message(admin, text=text, reply_markup=reply_markup)


async def admin_block(_: Client, message: Message, lang):
    text = message.text
    await db.update_user_blocked(text, 1)
    text = language.admin_block_text(lang=lang)
    await message.reply_text(text, reply_to_message_id=message.id)
    await db.update_step(admin, 'Admin-Block-Done')


async def admin_unblock(_: Client, message: Message, lang):
    text = message.text
    await db.update_user_blocked(text, 0)
    text = language.admin_unblock_text(lang=lang)
    await message.reply_text(text, reply_to_message_id=message.id)
    await db.update_step(admin, 'Admin-Unblock-Done')


async def admin_add_channel(_: Client, message: Message, lang):
    channel_name, channel_username = message.text.split(',')
    texts = language.admin_add_channel_texts(lang=lang)
    if 'https://t.me/' in channel_username:
        channels.add_channel(channel_name, channel_username)
        await message.reply_text(texts['success'], reply_to_message_id=message.id)
        await db.update_step(admin, 'Add-Channel-Done')
    else:
        await message.reply_text(texts['fail'], reply_to_message_id=message.id)


async def admin_remove_channel(_: Client, message: Message, lang):
    channel_username = message.text
    channels.remove_channel(channel_username)
    text = language.admin_remove_channel_text(lang=lang)
    await message.reply_text(text, reply_to_message_id=message.id)
    await db.update_step(admin, 'Remove-Channel-Done')


async def extra_get_seed(_: Client, message: Message, lang):
    chat_id = message.chat.id
    seed = message.text
    texts = language.seed_text(lang=lang)
    if not seed.isdigit():
        await message.reply_text(texts['error'])
    else:

        cbq.tasks[chat_id]['seed'] = seed
        await db.update_step(chat_id=chat_id, step='get-seed-done')

        await message.reply_text(texts['success'], reply_to_message_id=message.id)


async def admin_send_message(bot: Client, message: Message, lang):
    text = message.text
    texts = language.admin_send_message(lang=lang)
    msg = await message.reply_text(texts['wait'])
    result = await db.read_all_users()
    send_counter = 0
    block_counter = 0
    for user_id in result:
        user_id = user_id[0]
        try:
            await bot.send_message(int(user_id), text)
            send_counter += 1
        except (exceptions.UserIsBlocked, exceptions.PeerIdInvalid):
            block_counter += 1
            continue
    text = texts['success'] % (len(result), send_counter, block_counter)
    await msg.edit_text(text)
