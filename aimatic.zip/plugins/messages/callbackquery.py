from pyrogram import Client
from pyrogram.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.enums.parse_mode import ParseMode
from pyrogram.errors import exceptions
from plugins import language
from plugins.database import database as db
from plugins.filters import is_blocked
import re
import httpx
from config import admin, bot_username, image_channel_id, tron_wallet
from source import genius
import asyncio
from pyrogram.enums.chat_action import ChatAction
import logging

active_tasks = set()
tasks = dict()


def admin_panel_create_buttons(lang):
    texts = language.admin_panel_create_buttons(lang=lang)

    admin_panel_markup = InlineKeyboardMarkup([
        [InlineKeyboardButton(texts['status'], 'admin-status')],
        [InlineKeyboardButton(texts['block'], 'admin-block'),
         InlineKeyboardButton(texts['unblock'], 'admin-unblock')],
        [InlineKeyboardButton(texts['add-channel'], 'admin-add-channel'),
         InlineKeyboardButton(texts['remove-channel'], 'admin-remove-channel')],
        [InlineKeyboardButton(texts['send-message'], 'admin-send-message')]

    ])
    return admin_panel_markup


def update_task_setting(chat_id, lang, prompt=None):
    texts = language.task_settings_texts(lang=lang)
    if prompt:
        tasks[chat_id] = {'size': 'Portrait',
                          'model': 'Anime', 'seed': -1, 'prompt': prompt}

    user_task = tasks[chat_id]
    size = user_task['size']
    model = user_task['model']
    task_setting_markup = InlineKeyboardMarkup(
        [
            [InlineKeyboardButton(text=texts['size'], callback_data='change-size'),
             InlineKeyboardButton(text=size, callback_data='change-size')],
            [InlineKeyboardButton(text=texts['model'], callback_data='change-model'),
             InlineKeyboardButton(text=model, callback_data='change-model')],
            [InlineKeyboardButton(
                text=texts['extra-settings'], callback_data='extera-settings')],
            [InlineKeyboardButton(text=texts['generate'],
                                  callback_data='generate')],

        ]
    )
    return task_setting_markup, texts['main-text']


@Client.on_callback_query(is_blocked)
async def callback_query(bot: Client, query: CallbackQuery):
    data = query.data
    chat_id = query.from_user.id
    cases = [
        (r'lang-\w+', select_language),
        (r'buy-credit', buy_credit),
        (r'invite-link', invite_link),
        (r'submit-credit', submit_credit),
        (r'full-\d+', full_access_credit),
        (r'fake-\d+', fake_credit_request),
        (r'block-\d+', block_credit_request),
        (r'admin-\w+', admin_panel),
        # -----------
        (r'task-home', task_home),

        (r'change-size', change_size),
        (r'size-(normal|landscape|portrait)', change_size_done),

        (r'change-model', change_model),
        (r'model-(real|anime)', change_model_done),

        (r'extera-settings', extra_settings),
        (r'extra-seed', extra_settings_seed_done),

        (r'generate', generate),
        (r'OK-\w+', accept_public_image),
        (r'NO-\w+', reject_public_image)

    ]
    try:
        for pattern, callback in cases:
            if re.match(pattern, data):
                await callback(bot, query)
                break
    except exceptions.MessageNotModified:
        await query.answer('⚠️ Do not spam ⚠️', show_alert=True)
    except (ValueError, KeyError, TypeError):
        logging.warning('Exception occurred', exc_info=True)
        logging.info('PASSED')
        await bot.send_message(chat_id, language.restart())


async def select_language(_: Client, query: CallbackQuery):
    chat_id = query.from_user.id
    data = query.data
    lang = data.split('-')[1]
    await db.add_user_lang(chat_id=chat_id, lang=lang)
    text = language.select_language(lang=lang)
    await query.edit_message_text(text)


async def admin_panel(bot: Client, query: CallbackQuery):
    data = query.data
    message_id = query.message.id
    lang = await db.read_user_lang(chat_id=admin)
    lang = lang[0]
    texts = language.admin_panel_callback_query_texts(lang=lang)
    if data == 'admin-home':
        reply_markup = admin_panel_create_buttons(lang)
        await bot.edit_message_text(admin, message_id, texts['admin-home'], reply_markup=reply_markup)

    elif data == 'admin-block':
        await bot.send_message(admin, texts['admin-block'])
        await db.update_step(admin, 'Admin-Block')

    elif data == 'admin-unblock':
        await bot.send_message(admin, texts['admin-unblock'])
        await db.update_step(admin, 'Admin-Unblock')

    elif data == 'admin-status':
        reply_markup = InlineKeyboardMarkup(
            [[InlineKeyboardButton(texts['back'], 'admin-home')]])
        users = await db.read_all_users_count()
        blocked_users = await db.read_blocked_users()
        text = texts['admin-status'] % (users, blocked_users)
        await bot.edit_message_text(admin, message_id, text, reply_markup=reply_markup)

    elif data == 'admin-add-channel':
        await bot.send_message(admin, texts['admin-add-channel'])
        await db.update_step(admin, 'Add-Channel')

    elif data == 'admin-remove-channel':
        await bot.send_message(admin, texts['admin-remove-channel'])
        await db.update_step(admin, 'Remove-Channel')
    elif data == 'admin-send-message':
        await bot.send_message(admin, texts['admin-send-message'])
        await db.update_step(admin, 'Send-Message-To-Users')


async def invite_link(bot: Client, query: CallbackQuery):
    chat_id = query.from_user.id
    message_id = query.message.id
    lang = await db.read_user_lang(chat_id=chat_id)
    lang = lang[0]
    text = language.invite_link(lang)
    text = text % f'https: //t.me/{bot_username}?start={chat_id}'
    await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=text)


async def buy_credit(bot: Client, query: CallbackQuery):
    chat_id = query.from_user.id
    message_id = query.message.id
    lang = await db.read_user_lang(chat_id=chat_id)
    lang = lang[0]
    texts = language.buy_credit(lang=lang)
    text = texts['text'] % tron_wallet
    reply_markup = InlineKeyboardMarkup(
        [[InlineKeyboardButton(text=texts['next'], callback_data='submit-credit')]])
    await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=text, reply_markup=reply_markup,
                                parse_mode=ParseMode.MARKDOWN)


async def submit_credit(bot: Client, query: CallbackQuery):
    chat_id = query.from_user.id
    message_id = query.message.id
    lang = await db.read_user_lang(chat_id=chat_id)
    lang = lang[0]
    await db.update_step(chat_id, 'Submit-Credit')
    text = language.submit_credit(lang=lang)
    await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=text)


async def full_access_credit(bot: Client, query: CallbackQuery):
    chat_id = query.from_user.id
    message_id = query.message.id
    data = query.data
    user_chat_id = data.split('-')[1]
    await db.full_access_user_credit(chat_id=user_chat_id)
    lang = await db.read_user_lang(chat_id=chat_id)
    lang = lang[0]
    texts = language.full_access_credit(lang=lang)
    await bot.send_message(user_chat_id, texts['congratulation'])
    message_text = query.message.text
    text = message_text + '\n' + texts['accept']
    await bot.edit_message_text(chat_id, message_id, text)


async def fake_credit_request(bot: Client, query: CallbackQuery):
    chat_id = query.from_user.id
    message_id = query.message.id
    data = query.data
    message_text = query.message.text
    user_chat_id = data.split('-')[1]
    lang = await db.read_user_lang(chat_id=user_chat_id)
    lang = lang[0]
    texts = language.fake_credit_request(lang=lang)
    await bot.send_message(user_chat_id, texts['text'])
    lang = await db.read_user_lang(chat_id=chat_id)
    lang = lang[0]
    texts = language.fake_credit_request(lang=lang)
    text = message_text + '\n' + texts['reject']
    reply_markup = InlineKeyboardMarkup(
        [[InlineKeyboardButton(texts['block'], f'block-{user_chat_id}')]])
    await bot.edit_message_text(chat_id, message_id, text, reply_markup=reply_markup)


async def block_credit_request(bot: Client, query: CallbackQuery, ):
    chat_id = query.from_user.id
    message_id = query.message.id
    data = query.data
    message_text = query.message.text
    user_chat_id = data.split('-')[1]
    lang = await db.read_user_lang(chat_id=chat_id)
    lang = lang[0]
    texts = language.block_credit_request(lang=lang)
    await bot.send_message(user_chat_id, texts['text'])
    await db.update_user_blocked(user_chat_id, 1)
    text = message_text + '\n' + texts['block']
    await bot.edit_message_text(chat_id, message_id, text)


async def task_home(_, query: CallbackQuery):
    chat_id = query.from_user.id
    lang = await db.read_user_lang(chat_id=chat_id)
    lang = lang[0]
    reply_markup, text = update_task_setting(chat_id, lang=lang)
    await query.edit_message_text(text, reply_markup=reply_markup)


async def change_size(_, query: CallbackQuery):
    chat_id = query.from_user.id
    lang = await db.read_user_lang(chat_id=chat_id)
    lang = lang[0]
    texts = language.change_size(lang=lang)
    reply_markup = InlineKeyboardMarkup(
        [
            [InlineKeyboardButton(texts['size'], ' ')],
            [InlineKeyboardButton('Landscape', 'size-landscape'), InlineKeyboardButton('Portrait', 'size-portrait'),
             InlineKeyboardButton('Normal', 'size-normal')]
        ]
    )

    await query.edit_message_text(texts['text'], reply_markup=reply_markup)


async def change_size_done(_, query: CallbackQuery):
    global tasks
    chat_id = query.from_user.id
    data = query.data
    data = data.split('-')[1]
    lang = await db.read_user_lang(chat_id=chat_id)
    lang = lang[0]
    if data == 'portrait':
        tasks[chat_id]['size'] = 'Portrait'
    elif data == 'landscape':
        tasks[chat_id]['size'] = 'Landscape'
    else:
        tasks[chat_id]['size'] = 'Normal'

    reply_markup, text = update_task_setting(chat_id, lang=lang)
    await query.edit_message_text(text, reply_markup=reply_markup)


async def change_model(_, query: CallbackQuery):
    chat_id = query.from_user.id
    lang = await db.read_user_lang(chat_id=chat_id)
    lang = lang[0]
    texts = language.change_model(lang=lang)
    reply_markup = InlineKeyboardMarkup(
        [
            [InlineKeyboardButton(texts['model'], ' ')],
            [InlineKeyboardButton('❤️‍🔥 Realistic', 'model-real'),
             InlineKeyboardButton('‍🎌 Anime', 'model-anime')]
        ]
    )
    await query.edit_message_text(texts['text'], reply_markup=reply_markup)


async def change_model_done(_, query: CallbackQuery):
    global tasks
    chat_id = query.from_user.id
    data = query.data
    data = data.split('-')[1]
    lang = await db.read_user_lang(chat_id=chat_id)
    lang = lang[0]
    if data == 'anime':
        tasks[chat_id]['model'] = 'Anime'
    else:
        tasks[chat_id]['model'] = 'Realistic'

    reply_markup, text = update_task_setting(chat_id, lang=lang)
    await query.edit_message_text(text, reply_markup=reply_markup)


async def extra_settings(_, query: CallbackQuery):
    chat_id = query.from_user.id
    seed = tasks[chat_id]['seed']
    lang = await db.read_user_lang(chat_id=chat_id)
    lang = lang[0]
    texts = language.extra_settings(lang=lang)
    reply_markup = InlineKeyboardMarkup(
        [
            [InlineKeyboardButton(texts['extra-settings'], ' ')],
            [InlineKeyboardButton('♻️ Seed', 'extra-seed'),
             InlineKeyboardButton(f'{seed}', 'extra-seed')],
            [InlineKeyboardButton(texts['back'], 'task-home')]
        ]
    )

    await query.edit_message_text(texts['text'], reply_markup=reply_markup)


async def extra_settings_seed_done(bot: Client, query: CallbackQuery):
    global tasks
    chat_id = query.from_user.id
    await db.update_step(chat_id, 'extra-settings-seed')
    await bot.send_message(chat_id, '♻️ Enter your seed')


async def generate(bot: Client, query: CallbackQuery):
    chat_id = query.from_user.id
    user_credit = await db.read_user_credit(chat_id=chat_id)
    lang = await db.read_user_lang(chat_id=chat_id)
    lang = lang[0]
    texts = language.generate(lang=lang)
    if user_credit < 1:
        await query.edit_message_text(texts['not-enough-credit'])
    else:
        if chat_id in active_tasks:
            await query.edit_message_text(texts['active-task'])
        else:
            user_task = tasks[chat_id]
            prompt = user_task['prompt']
            model = user_task['model']
            size = user_task['size']
            seed = user_task['seed']
            await query.edit_message_text(texts['wait'])
            try:
                logging.info('Prompt: %s', prompt)
                active_tasks.add(chat_id)
                task_id, account_token, email = await genius.start_task(prompt=prompt, model_name=model,
                                                                        size=size, seed=seed)
                await query.edit_message_text(texts['generate'])
                task_status = await genius.check_task(token=account_token, task_id=task_id, email=email)
                counter = 0
                while task_status == 0:
                    if counter > 30:
                        await query.edit_message_text(
                            texts['failed'])
                        active_tasks.remove(chat_id)
                        break
                    else:
                        task_status = await genius.check_task(token=account_token, task_id=task_id, email=email)
                        counter += 1
                        await asyncio.sleep(10)
                else:
                    img_url = task_status
                    seed = await genius.get_task_detail(task_id=task_id, token=account_token)
                    await bot.send_chat_action(chat_id, ChatAction.UPLOAD_PHOTO)
                    image, image_token = await genius.get_image(img_url)
                    caption = f'Seed: {seed}\n🤖 Generated by @{bot_username}'
                    msg = await bot.send_photo(chat_id, photo=image, caption=caption,
                                               reply_to_message_id=query.message.reply_to_message_id)
                    if size == 'Normal':
                        await db.update_user_credit(chat_id=chat_id, number=5)
                    else:
                        await db.update_user_credit(chat_id=chat_id, number=10)
                    lang = await db.read_user_lang(chat_id=admin)
                    if lang is not None:
                        lang = lang[0]
                        admin_texts = language.generate_admin_buttons(
                            lang=lang)
                    else:
                        admin_texts = texts
                    reply_markup = InlineKeyboardMarkup(
                        [
                            [InlineKeyboardButton(
                                admin_texts['accept'], f'OK-{image_token}')],
                            [InlineKeyboardButton(
                                admin_texts['reject'], f'NO-{image_token}')]
                        ]
                    )
                    text = f'''
---Task Detail---
👥 Model: {model}
🖼 Size: {size}
📝 Prompt: {prompt}'''
                    await query.edit_message_text(text=text)
                    active_tasks.remove(chat_id)
                    try:
                        await bot.send_photo(admin, msg.photo.file_id, caption=text, reply_markup=reply_markup)
                    except exceptions.bad_request_400.MediaCaptionTooLong:
                        await bot.send_photo(admin, msg.photo.file_id, caption=text[:1021] + '...', reply_markup=reply_markup)

                    await asyncio.sleep(60)
                    await bot.delete_messages(chat_id, msg.id)

            except httpx.ConnectTimeout:
                text = language.try_again(lang=lang)
                await bot.send_message(chat_id, text)
            except Exception:
                await bot.send_message(chat_id, texts['failed'])
                active_tasks.remove(chat_id)
                logging.error("Exception occurred", exc_info=True)


async def accept_public_image(bot: Client, query: CallbackQuery):
    _, image_token = query.data.split('-')
    image, _ = await genius.get_image(image_token)
    caption = query.message.caption
    await query.message.delete()
    await bot.send_photo(image_channel_id, image, caption=f'{caption}\n@{bot_username}')


async def reject_public_image(_: Client, query: CallbackQuery):
    _, image_token = query.data.split('-')
    await query.message.delete()
