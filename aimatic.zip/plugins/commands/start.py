from pyrogram import Client, filters
from pyrogram.types import Message, KeyboardButton, ReplyKeyboardMarkup
from plugins.database import database as db
from config import admin
from pyrogram.errors import exceptions
from plugins import language
from plugins.commands.settings import languages_reply_markup


@Client.on_message(filters.command('start') & filters.private)
async def start(bot: Client, message: Message):
    commands = message.command
    chat_id, firstname = message.chat.id, message.chat.first_name
    username = message.chat.username
    if commands is not None and len(commands) == 2:
        inviter = commands[1]
        if inviter.isdigit():
            if inviter != str(chat_id):
                result = await db.read_referrals(inviter)
                if result is None:

                    text = f'''
🎉 Congratulations 🥳
{firstname} joined the robot with your invite link and you received 100 credit 💰🤑'''
                    try:
                        await bot.send_message(chat_id=inviter, text=text)
                        await db.add_referral_and_update_credit(inviter, chat_id)
                    except exceptions.PeerIdInvalid:
                        pass
    lang = await db.read_user_lang(chat_id)
    if lang is None:
        text = f'''
Please select your language 🇺🇸
        
لطفا زبان خود را انتخاب کنید 🇮🇷'''

        await message.reply_text(text, reply_markup=languages_reply_markup)
        await db.add_user(chat_id, username, firstname)
        await db.add_step(chat_id)
    else:
        lang = lang[0]
        buttons = language.dashboard_buttons_text(lang)

        dashboard_buttons = [
            [KeyboardButton(buttons['generate'])],
            [KeyboardButton(buttons['my-account'])],
        ]
        dashboard = ReplyKeyboardMarkup(dashboard_buttons, resize_keyboard=True)
        admin_dashboard = ReplyKeyboardMarkup(dashboard_buttons + [[KeyboardButton(buttons['admin'])]],
                                              resize_keyboard=True)

        if chat_id == admin:
            reply_markup = admin_dashboard
        else:
            reply_markup = dashboard
        text = language.welcome_text(lang)
        text = text % firstname
        await message.reply_text(text, reply_markup=reply_markup)
        await db.add_step(chat_id)
