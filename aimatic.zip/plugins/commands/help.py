from pyrogram import Client, filters
from pyrogram.types import Message
from config import image_channel_link


@Client.on_message(filters.command('help') & filters.private)
async def help_guide(_: Client, message: Message):
    text = f'''
For better production, you can join the channel below and read the guide for using prompt and content created by users 🇺🇸

برای بازدهی بهتر شما میتوانید وارد کانال زیر شوید و راهنمای استفاده از ربات و تصاویر ایجاد شده توسط باقی کاربران را ببینید 🇮🇷
{image_channel_link}'''
    await message.reply_text(text)
