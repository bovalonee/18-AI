from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardButton, InlineKeyboardMarkup

languages_reply_markup = InlineKeyboardMarkup(
    [
        [InlineKeyboardButton('English 🇺🇸', 'lang-en'), InlineKeyboardButton('فارسی 🇮🇷', 'lang-fa')]
    ]
)


@Client.on_message(filters.command('settings') & filters.private)
async def settings(_: Client, message: Message):
    text = f'''
    Please select your language 🇺🇸

    لطفا زبان خود را انتخاب کنید 🇮🇷'''
    await message.reply_text(text, reply_markup=languages_reply_markup)
