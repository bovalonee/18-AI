api_id = 29100203  # Your account API ID
api_hash = 'b3ec2c7239bdadafcad3aacb7206f5a8'  # Your account API Hash
bot_token = '6555060361:AAH6dzhtC2A3gyIJ_617CXLzgJQvyTCBo9U'  # Your BOT TOKEN
bot_username = 'MaticStable_bot'  # Your BOT Username
admin = 6922658186  # Admin ID

image_channel_link = 'https://t.me/+XN4_LK1VjHg5NjI9'  # Your channel link
image_channel_id = -1002131761966  # Your channel ID

tron_wallet = 'TLKkjHkwaLwbU8HdeVqC3LEjqEaBbgGsU3'  # Your Tron wallet
