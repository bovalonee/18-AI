import logging

import httpx
import asyncio
from source import tempmail
from bs4 import BeautifulSoup
from plugins.database import database as db


async def send_code(email):
    url = 'https://api.live3d.io/api/v1/register_by_email'
    data = {"username": "bot", "email": email, "password": "Aa123456",
            "password_confirmation": "Aa123456"}

    async with httpx.AsyncClient() as client:
        response = await client.post(
            url=url, json=data)
        rjson = response.json()
        detail = rjson.get('detail', '')
        message = rjson.get('message', '')
        if message == 'OK':
            return
        else:
            if 'email already exists' in detail:
                raise ValueError('email already exists')
            else:
                raise ValueError(str(rjson))


async def verify_registration(url):
    data = {'token': url.split('token=')[1]}
    async with httpx.AsyncClient() as client:
        response = await client.get(url)
        if response.status_code == 200:
            response = await client.post('https://api.live3d.io/api/v1/email_verify', json=data)
            rjson = response.json()
            message = rjson.get('message', '')
            if message == 'OK':
                return
            else:
                raise ValueError(str(rjson))


async def login(email):
    url = 'https://api.live3d.io/api/v1/login_by_email'
    data = {"email": email, "password": "Aa123456"}
    async with httpx.AsyncClient() as client:
        response = await client.post(url=url, json=data)
        rjson = response.json()
        api_token = rjson.get('api_token')
        if api_token is not None:
            return api_token
        else:
            logging.error('error', exc_info=True)
            return None


async def start_task(size, model_name, prompt, seed):
    async def send_request():

        headers = {
            'Authorization': f'Bearer {token}'
        }
        url = 'https://api.live3d.io/api/v1/generation/generate'
        async with httpx.AsyncClient() as client:
            try:
                _response = await client.post(url=url, json=data, headers=headers)
            except httpx.ConnectTimeout:
                raise TimeoutError
            rjson = _response.json()
            message = rjson.get('message')
            if message == 'OK':
                await db.update_account_credit(email=email, number=points)
                task_id = rjson.get('data').get('id')
                return [task_id, token, email]
            else:
                await db.update_account_is_active(email=email, is_active=0)
                detail = rjson.get('detail')
                if detail == 'point not enough':
                    return None

    models = {'Anime': 24, 'Realistic': 42}
    model_id = models[model_name]
    sizes = {'Portrait': {'width': 512, 'height': 768, 'consume_points': 10},
             'Landscape': {'width': 768, 'height': 512, 'consume_points': 10},
             'Normal': {'width': 512, 'height': 512, 'consume_points': 5}}

    size_scales = sizes[size]
    points = size_scales['consume_points']
    data = {
        'model_id': model_id,
        'width': size_scales['width'],
        'height': size_scales['height'],
        'prompt': prompt,
        "consume_points": points,
        "img_url": "",
        "type": 1,
        "divide_ratio": "",
        "matrix_mode": "",
        "gen_type": "text_to_image",
        "request_data": {
            "loras": [],
            "resolution": "1",
            "image_number": 1,
            "negative_prompt": "(worst quality, low quality:1.4), (greyscale, monochrome:1.1), cropped, lowres , username, blurry, trademark, watermark, title, multiple view, Reference sheet, curvy, plump, strabismus, clothing cutout, side slit,worst hand, (ugly face:1.2), extra leg, extra arm, bad foot, text, name, badhandv4, easynegative, EasyNegativeV2",
            "sampling": {
                "step": 25,
                "method": "DPM++ 2M Karras"
            },
            "cfg": {
                "scale": 7,
                "seed": int(seed)
            },
            "high_priority": False,
            "control_weight": 1}
    }

    result = await db.read_accounts(credit=points)
    for row in result:
        email = row[0]
        token = await login(email=email)
        await db.update_account_is_active(email=email, is_active=1)
        response = await send_request()
        if response is not None:
            return response

    email, token = await new_token()
    await db.update_account_is_active(email=email, is_active=1)
    response = await send_request()
    return response


# https://api.live3d.io/api/v1/generation/get_models

async def check_task(token, task_id, email):
    headers = {
        'Authorization': f'Bearer {token}'
    }
    url = f'https://api.live3d.io/api/v1/generation/check_generate_state?ai_art_id={task_id}'
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(url=url, headers=headers)
        except httpx.ConnectTimeout:
            raise TimeoutError()
        rjson = response.json()
        message = rjson.get('message')
        if message == 'OK':
            data = rjson.get('data')
            if data['status'] == 0:
                return 0
            else:
                await db.update_account_is_active(email=email, is_active=0)
                image = data['url'][0]
                return image

    #     {"code":200,"message":"OK","data":{"id":2900760,"status":0,"url":[]}}

    #     {"code": 200,message": "OK","data": {"id": 2900863,"status": 1,"url": ["anime/b74464cb7eef23fe1f045e0b4bd12cfb.webp"]}}


async def get_image(image_link):
    url = f'https://art-global.yimeta.ai/{image_link}'
    return url, image_link
    # async with httpx.AsyncClient() as client:
    #     response = await client.get(url)
    #     name = image_link.split('/')[1]
    #     with open(name, 'wb') as out_file:
    #         out_file.write(response.content)
    #     del response
    # return name


async def new_token():
    email = await tempmail.get_email()
    await send_code(email=email)
    inbox = await tempmail.refresh(email)
    while not inbox:
        inbox = await tempmail.refresh(email)
        await asyncio.sleep(2)
    email_id = inbox[0]['id']
    email_detail = await tempmail.get_message_detail(email, email_id)
    soup = BeautifulSoup(email_detail['body'], 'html.parser')
    register_link = soup.find('a').attrs.get('href')
    await verify_registration(register_link)
    api_token = await login(email)
    await db.add_account(email)
    return email, api_token


async def get_task_detail(task_id, token):
    headers = {
        'Authorization': f'Bearer {token}'
    }
    url = f'https://api.live3d.io/api/v1/generation/ai_art_detail?id={task_id}'
    async with httpx.AsyncClient() as client:
        response = await client.get(url=url, headers=headers)
        rjson = response.json()
        seed = rjson.get('data').get('seed')
        return seed
#         {'code': 200, 'message': 'OK', 'data': {'id': 2952271, 'input_image': '', 'url': ['anime/cfc430c6ccb000c31f665456b102fe69.webp'], 'prompt': 'A 40 years old horny and sexy bitch and slut milf with large breasts and wet pussy fucked from vagina  and mouth by 2 black guys with big dicks,(porn),anime style,manga style,hentai,story line,story', 'negative': '(worst quality, low quality:1.4), (greyscale, monochrome:1.1), cropped, lowres , username, blurry, trademark, watermark, title, multiple view, Reference sheet, curvy, plump, strabismus, clothing cutout, side slit,worst hand, (ugly face:1.2), extra leg, extra arm, bad foot, text, name, badhandv4, easynegative, EasyNegativeV2', 'model': {'id': 24, 'name': 'Anime'}, 'width': 512, 'height': 768, 'resolution': 1, 'sampling': {'step': 25, 'method': 'DPM++ 2M Karras'}, 'CFG_scale': 7, 'seed': '146988933', 'loras': []}}


# asyncio.run(verify_registration())
# asyncio.run(login('38n02k1nbti1@ezztt.com'))

# {
#     "code": 200,
#     "message": "OK",
#     "data": {
#         "id": 2944667,
#         "input_image": "",
#         "url": [
#             "anime/02309be77bcff23e690f7a0241476aad.webp"
#         ],
#         "prompt": "(masterpiece), best quality, expressive eyes, perfect face",
#         "negative": "(worst quality, low quality:1.4), (greyscale, monochrome:1.1), cropped, lowres , username, blurry, trademark, watermark, title, multiple view, Reference sheet, curvy, plump, fat, strabismus, clothing cutout, side slit,worst hand, (ugly face:1.2), extra leg, extra arm, bad foot, text, name, badhandv4, easynegative, EasyNegativeV2",
#         "model": {
#             "id": 24,
#             "name": "Anime"
#         },
#         "width": 512,
#         "height": 768,
#         "resolution": 1,
#         "sampling": {
#             "step": 25,
#             "method": "DPM++ 2M Karras"
#         },
#         "CFG_scale": 7,
#         "seed": "3113819211",
#         "loras": []
#     }
# }
