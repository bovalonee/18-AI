import httpx


async def get_email():
    url = 'https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1'
    async with httpx.AsyncClient() as client:
        response = await client.get(url=url, timeout=10)
        email = response.json()[0]
        return email


async def refresh(email):
    username, domain = email.split('@')
    url = f'https://www.1secmail.com/api/v1/?action=getMessages&login={username}&domain={domain}'
    async with httpx.AsyncClient() as client:
        response = await client.get(url=url, timeout=10)
        return response.json()


async def get_message_detail(email, email_id):
    username, domain = email.split('@')
    url = f'https://www.1secmail.com/api/v1/?action=readMessage&login={username}&domain={domain}&id={email_id}'
    async with httpx.AsyncClient() as client:
        response = await client.get(url=url, timeout=10)
        return response.json()
